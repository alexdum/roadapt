export default global.L;
